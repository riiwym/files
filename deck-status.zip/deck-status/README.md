# Decky Status

A fork of [andrewburgess/steamdeck-discord-status](https://github.com/andrewburgess/steamdeck-discord-status) to make it completely client-less!

# WARNING

This requires you to use your discord token meaning it IS against TOS (iirc) so use this at your own risk!

## How to Use

1. Get your discord token
2. Enter it in
3. Tap "Save Token & Connect"